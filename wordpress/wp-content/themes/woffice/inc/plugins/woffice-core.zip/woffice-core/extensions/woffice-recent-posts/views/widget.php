<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

echo $before_widget;

echo $before_title;
    echo $title;
echo $after_title;
$recent_posts = wp_get_recent_posts(array(
    'numberposts' => $number_of_item,
    'post_status' => 'publish'
));

?>
<ul class="list-styled">
    <?php
    if(!empty($recent_posts)){
        foreach( $recent_posts as $post_item ) : ?>
            <li class="list-recent-posts">
                <div class="row recent-posts-item align-items-center">
                    <div  class="col-md-4 recent-posts-thumb">
                        <?php echo get_the_post_thumbnail($post_item['ID'], 'thumbnail'); ?>
                    </div>  
                    <div class="col-md-8 recent-posts-content pl-0">
                        <h3 class="recent-posts-title mb-0"><?php echo $post_item['post_title']; ?></h3>
                        <span class="font-rg1"><?php echo get_the_date('F j, Y g:i a',$post_item['ID']); ?></span>
                    </div>
                </div>
            </li>
        <?php endforeach; }?>
</ul>
<?php  echo $after_widget ?>