$(document).ready(function(){
	$(".mobileLinkToggle").click(function(){
		$(".headerMenu").toggle();
	})
})